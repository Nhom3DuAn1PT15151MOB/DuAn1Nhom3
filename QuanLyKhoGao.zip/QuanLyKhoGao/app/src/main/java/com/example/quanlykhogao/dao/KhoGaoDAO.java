package com.example.quanlykhogao.dao;

public class KhoGaoDAO {
}
