package com.example.quanlykhogao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LogInActivity extends AppCompatActivity {
    EditText edUserName, edPassword;
    Button btnLogin, btnCancel;
    CheckBox chkRememberPass;
    String stU, stP;
    TextView tvResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        edPassword = findViewById(R.id.edPasswordLogin);
        edUserName = findViewById(R.id.edUserNameLogin);
        chkRememberPass = findViewById(R.id.checkbox);
        remenberUP(edUserName.getText().toString(),edPassword.getText().toString(),true);
    }

    private void remenberUP(String u, String p, boolean status) {
        SharedPreferences sharedPreferences = getSharedPreferences("USER_FILE",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (status == false){
            editor.clear();
        }
        else {
            editor.putString("USERNAME",u);
            editor.putString("PASSWORD",p);
            editor.putBoolean("REMAMBER", status);

        }
    }
    public void shaveUP(View view) {
        String u = edUserName.getText().toString();
        String p = edPassword.getText().toString();
        boolean status = chkRememberPass.isChecked();
    }
    public void btnLogIn(View view) {
        stU = edUserName.getText().toString();
        stP = edPassword.getText().toString();
        if (stU.isEmpty() || stP.isEmpty()) {
            Toast.makeText(this, "Khong duoc de trong", Toast.LENGTH_LONG).show();
        } else {
            if (checkLogin(stU, stP) > 0) {
                Toast.makeText(this, "Login thanh cong", Toast.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(LogInActivity.this, MainActivity.class));
                    }
                }, 1000);
            } else {
                Toast.makeText(this, "Sai thong tin dang nhap", Toast.LENGTH_LONG).show();

            }
        }
    }

    public int checkLogin(String u, String p) {

        if (u.equals("admin") && p.equals("admin")) {
            return 1;
        } else {
            return -1;
        }
    }

    public void quenPass(View view) {
        Intent intent = new Intent(LogInActivity.this,QuenPassActivity.class);
        startActivity(intent);
    }

    public void btnDangKy(View view) {
        Intent intent = new Intent(this,NguoiDungActivity.class);
        startActivity(intent);
    }
}
