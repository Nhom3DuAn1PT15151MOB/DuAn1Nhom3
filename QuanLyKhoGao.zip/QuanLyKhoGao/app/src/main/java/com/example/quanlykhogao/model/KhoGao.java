package com.example.quanlykhogao.model;

public class KhoGao {
}
