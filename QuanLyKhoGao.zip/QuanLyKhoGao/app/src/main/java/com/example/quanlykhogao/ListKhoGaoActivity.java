package com.example.quanlykhogao;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListKhoGaoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_kho_gao);
    }
}
